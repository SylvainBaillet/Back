<?php
require_once("include/init.php");
require_once("include/header.php");
?>

<div class="container" id="mainLoisirs">

    <h2>Mes loisirs</h2>

    <p>J'aime par dessus tout la musique et le son ! Composer, faire des prises de sons et les travailler, les déstrucurer dans tous les sens.</p>
    <p>Je prends beaucoup de photos et de vidéos, que j'aime ensuite retravailler, en faire des montages pour le loisir ou en projet professionnel.</p>
    <p>J'aime également tout ce qui attrait à l'informatique. De la maintenance matérielle à la programmation, le web etc...</p>
    <p>Mes autres loisirs sont la lecture, le cinéma, le sport, les voyages, l'histoire, visiter des musées, les balades, l'architecture et la nature.</p>
</div>

<?php
require_once("include/footer.php");
?>