    </section>
        
    <!-- Footer -->
        <footer class="page-footer font-small indigo" id="footer">

        <!-- Copyright -->
        <div class="footer-copyright text-center py-3">© 2019 Copyright <a href="connexion.php?action=validate">:</a>
            <a href="https://mdbootstrap.com/education/bootstrap/"> Sylvain Baillet</a>
        </div>
        <!-- Copyright -->

        </footer>
    <!-- fin Footer -->
        
    </div>
    <!-- fin container-fluid -->

    <!-- bouton ancre -->
    <section id="ancre">
    <a href="#navbar1"><button type="button"><i class="fas fa-arrow-alt-circle-up btn-ancre" aria-hidden="true"></i></button></a>
    </section>
    <!-- liens jQuery et JavaScript -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/site_portfolio.js"></script>
    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>

